<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/srv/disk2/2893271/www/newsoc.dx.am/user/config/plugins/error.yaml',
    'modified' => 1586812260,
    'data' => [
        'enabled' => true,
        'routes' => [
            404 => '/error'
        ]
    ]
];
