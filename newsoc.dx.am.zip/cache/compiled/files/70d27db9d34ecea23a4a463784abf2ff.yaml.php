<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/srv/disk2/2893271/www/newsoc.dx.am/user/plugins/markdown-notices/markdown-notices.yaml',
    'modified' => 1584649857,
    'data' => [
        'enabled' => true,
        'built_in_css' => true,
        'base_classes' => 'notices',
        'level_classes' => [
            0 => 'yellow',
            1 => 'red',
            2 => 'blue',
            3 => 'green'
        ]
    ]
];
