<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/srv/disk2/2893271/www/newsoc.dx.am/user/accounts/admin.yaml',
    'modified' => 1586810827,
    'data' => [
        'access' => [
            'admin' => [
                'super' => 'true',
                'login' => 'true',
                'cache' => 'true',
                'configuration' => 'true',
                'configuration_system' => 'true',
                'configuration_site' => 'true',
                'configuration_media' => 'true',
                'configuration_info' => 'true',
                'settings' => 'true',
                'pages' => 'true',
                'maintenance' => 'true',
                'statistics' => 'true',
                'plugins' => 'true',
                'themes' => 'true',
                'tools' => 'true',
                'users' => 'true'
            ]
        ],
        'email' => 'airisdead1@gmail.com',
        'fullname' => 'Admin',
        'hashed_password' => '$2y$10$RGQBfImutus5E861JNBtB.M/WxJw5BYhZ62qrjtJGeSieRAsHjcpK',
        'title' => 'Site Administrator',
        'state' => 'enabled',
        'password' => NULL,
        'language' => 'en',
        'twofa_enabled' => false,
        'twofa_secret' => 'SVLRGHSASHR2TJRBCQYKZHYHOKEVHGNE',
        'avatar' => [
            'user/accounts/avatars/ukLUmCRxOgQnc38.jpg' => [
                'name' => 'ukLUmCRxOgQnc38.jpg',
                'type' => 'image/jpeg',
                'size' => 290876,
                'path' => 'user/accounts/avatars/ukLUmCRxOgQnc38.jpg'
            ]
        ],
        'info' => NULL,
        'groups' => NULL
    ]
];
