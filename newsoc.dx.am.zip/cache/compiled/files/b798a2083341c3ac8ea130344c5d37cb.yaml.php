<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/srv/disk2/2893271/www/newsoc.dx.am/user/config/streams.yaml',
    'modified' => 1586809719,
    'data' => [
        
    ]
];
