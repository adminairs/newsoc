<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/srv/disk2/2893271/www/newsoc.dx.am/user/plugins/problems/problems.yaml',
    'modified' => 1584649857,
    'data' => [
        'enabled' => true,
        'built_in_css' => true
    ]
];
