<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/srv/disk2/2893271/www/newsoc.dx.am/user/config/site.yaml',
    'modified' => 1586809672,
    'data' => [
        'title' => 'SOC ORGANIZATION PVT LTD',
        'author' => [
            'name' => 'Joe Bloggs',
            'email' => 'airisdead1@gmail.com'
        ],
        'metadata' => [
            'description' => 'Grav is an easy to use, yet powerful, open source flat-file CMS'
        ]
    ]
];
