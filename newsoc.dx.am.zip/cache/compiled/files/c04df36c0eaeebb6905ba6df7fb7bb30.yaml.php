<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/srv/disk2/2893271/www/newsoc.dx.am/user/config/themes/quark.yaml',
    'modified' => 1586811442,
    'data' => [
        'enabled' => true,
        'production-mode' => true,
        'grid-size' => 'grid-md',
        'header-fixed' => true,
        'header-animated' => true,
        'header-dark' => false,
        'header-transparent' => false,
        'sticky-footer' => true,
        'blog-page' => '/blog',
        'spectre' => [
            'exp' => true,
            'icons' => true
        ],
        'custom_logo' => [
            
        ],
        'custom_logo_mobile' => [
            
        ]
    ]
];
