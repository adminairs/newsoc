<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/srv/disk2/2893271/www/newsoc.dx.am/user/plugins/problems/languages.yaml',
    'modified' => 1584649857,
    'data' => [
        'en' => [
            'PLUGIN_PROBLEMS' => [
                'BUILTIN_CSS' => 'Use built in CSS',
                'BUILTIN_CSS_HELP' => 'Include the CSS provided by the Problems plugin'
            ]
        ],
        'ru' => [
            'PLUGIN_PROBLEMS' => [
                'BUILTIN_CSS' => 'Использовать встроенный CSS',
                'BUILTIN_CSS_HELP' => 'Использовать CSS, предоставленный плагином Problems'
            ]
        ],
        'uk' => [
            'PLUGIN_PROBLEMS' => [
                'BUILTIN_CSS' => 'Використовувати вбудований CSS',
                'BUILTIN_CSS_HELP' => 'Використовувати CSS, наданий плагіном Problems'
            ]
        ]
    ]
];
